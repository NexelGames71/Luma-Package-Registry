# Dynamic Lighting Package

## Overview

The Dynamic Lighting package provides a comprehensive real-time lighting system for Luma Engine. It includes support for dynamic light sources, shadows, and various lighting effects.

## Features

- Real-time dynamic lighting
- Shadow casting and receiving
- Multiple light types (point, spot, directional)
- Performance optimized rendering
- Easy-to-use API

## Getting Started

1. Install the package through the Luma Package Manager
2. Add a DynamicLight component to your scene
3. Configure the light properties in the inspector
4. Run your scene to see the dynamic lighting in action

## API Reference

### DynamicLightingSystem

Main system class for managing all dynamic lights in the scene.

### DynamicLight

Represents a single dynamic light source with configurable properties.

## Examples

See the Samples folder for example implementations.

