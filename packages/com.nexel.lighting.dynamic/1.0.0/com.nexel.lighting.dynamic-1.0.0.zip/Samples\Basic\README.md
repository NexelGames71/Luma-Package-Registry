# Basic Dynamic Light Example

This sample demonstrates how to set up a basic dynamic light in your scene.

## Setup

1. Create a new scene
2. Add a DynamicLight component to a GameObject
3. Configure the light intensity, range, and color
4. Run the scene to see the dynamic lighting effect

## Code Example

```csharp
using Nexel.Lighting.Dynamic;

// Get the lighting system
var lightingSystem = FindObjectOfType<DynamicLightingSystem>();

// Create a new dynamic light
var light = new DynamicLight
{
    Intensity = 1.0f,
    Range = 10.0f,
    Color = UnityEngine.Color.white
};

// Add the light to the system
lightingSystem.AddLight(light);
```

